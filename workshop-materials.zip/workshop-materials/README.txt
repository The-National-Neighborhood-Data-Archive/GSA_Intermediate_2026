Linking NaNDA With Your Data
GSA 2026 Annual Scientific Meeting, Breakout 2 (Intermediate)

You do not need to run any of this. The full notebook, with every output
already rendered, is at:

  https://the-national-neighborhood-data-archive.github.io/GSA_Intermediate_2026/

Cite it: https://doi.org/10.5281/zenodo.23071407

MANIFEST

  README.txt          this file
  notebook.qmd        the notebook source (R). Open workshop.Rproj in RStudio
                      and press Render to run it yourself.
  workshop.Rproj      the RStudio project. Open it first so every path resolves.
  _variables.yml      names, DOIs and URLs the notebook reads

  site/               the notebook and the before-you-begin page, saved for
                      offline reading. Open site/notebook.html in any browser;
                      no internet needed.

  data/               what the scripts read
    synthetic_data_v20260924.csv           the synthetic survey
    synthetic_data_v20260924_tract10.csv   the same rows with a synthetic 2010
                                           tract ID added, for the tract scripts
    codebook_synthetic_data_v20260924.log  the codebook for both
    zip_to_zcta_2019.xlsx                  the ZIP-to-ZCTA crosswalk (UDS Mapper, 2019)
    nanda/                                 EMPTY except README.md. The NaNDA files
                                           come from ICPSR, which needs a free
                                           account; the README says which files
                                           and where to put them. You only need
                                           them to re-run the code.

  Scripts: one folder per language, two scripts per folder. Same steps, same
  block headers, so any two read side by side.

                    ZIP-to-ZCTA route            tract route
                    (what the session runs)      (a tract ID already on your data)
    r/              linking_nanda_zcta.R         linking_nanda_tract.R
    stata/          linking_nanda_zcta.do        linking_nanda_tract.do
    python/         linking_nanda_zcta.py        linking_nanda_tract.py

  Each folder has a README.md. r/README.md explains the tract route and lists
  where a tract ID comes from. Geocoding itself is not part of these materials.

Questions: nanda-admin@umich.edu
