Linking NaNDA With Your Data
GSA 2026 Annual Scientific Meeting — Breakout 2 (Intermediate)

You do not need to run any of this. The full notebook, with every output
already rendered, is at:

  https://the-national-neighborhood-data-archive.github.io/GSA_Intermediate_2026/

Cite it: https://doi.org/10.5281/zenodo.23071407

What's in here:
  site/      the notebook and the before-you-begin page, saved for offline
             reading. Open site/notebook.html in any browser; no internet needed.
  data/      synthetic dataset, its codebook, and the ZIP-to-ZCTA crosswalk.
             The NaNDA files are NOT in here — they come from ICPSR, which
             needs a free account. data/nanda/README.md has the three
             downloads and where to put them. You only need them if you want
             to re-run the code; the notebook already shows every output.
  stata/     the Stata version of the notebook, step for step
  python/    the Python version of the notebook, step for step
  notebook.qmd   the notebook source (R, with the same Stata and Python
                 steps shown one tab away on the web page). Open workshop.Rproj
                 in RStudio and press Render to run it yourself.

Questions: nanda-admin@umich.edu
